#!/bin/sh
#desc:Configure IVI
#package:odcgi_scada
#type:local

# This script will allow the configuration of OD's IVI
# If the configuration directory does not exist

CFGDIR="/etc/opendomo/ivi"

exit 1
